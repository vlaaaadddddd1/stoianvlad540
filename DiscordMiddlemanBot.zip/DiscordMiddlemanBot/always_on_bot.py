#!/usr/bin/env python3
"""
Ultimate 24/7 Discord Bot Solution - Combined Bot and Web Server
"""
import os
import time
import threading
import datetime
import signal
import sys
from flask import Flask, render_template_string
import asyncio
import discord
from discord.ext import commands, tasks
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    print("ERROR: No Discord token found in .env file!")
    sys.exit(1)

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="p ", intents=intents)

# Web server for keep-alive
app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is alive!"

@app.route('/ping')
def ping():
    return "Pong!"

# Set up the bot
@bot.event
async def on_ready():
    print(f"Bot logged in as {bot.user}")
    print("Bot is ready to use!")
    heartbeat.start()

@tasks.loop(minutes=5)
async def heartbeat():
    """Keep the connection alive with periodic activity"""
    print(f"[{datetime.datetime.now()}] Heartbeat check...")

def run_flask():
    """Run the Flask web server"""
    app.run(host='0.0.0.0', port=8080)

def run_bot():
    """Run the Discord bot with retries"""
    while True:
        try:
            bot.run(TOKEN)
        except Exception as e:
            print(f"Bot crashed with error: {e}")
            print("Restarting in 10 seconds...")
            time.sleep(10)
            continue

if __name__ == "__main__":
    # Start the Flask server in a separate thread
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.daemon = True
    flask_thread.start()
    print("Web server started!")

    # Import the correct run function from our bot.py
    from bot import run_bot as start_bot
    print("Bot code imported successfully.")

    # Run the bot in the main thread with auto-restart
    run_bot()