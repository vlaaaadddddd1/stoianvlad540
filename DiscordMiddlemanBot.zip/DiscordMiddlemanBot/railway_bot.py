#!/usr/bin/env python3
"""
Railway-optimized version of the Discord bot.
This version does not include the keep-alive server as Railway
provides 24/7 uptime natively.
"""
import os
import time
import logging
import discord
from discord.ext import commands, tasks
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('railway_bot')

# Load environment variables
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    logger.error("No Discord token found in environment!")
    raise ValueError("DISCORD_TOKEN environment variable is required")

# Bot setup
intents = discord.Intents.default()
intents.message_content = True

# Use AutoShardedBot for improved performance and reliability
bot = commands.AutoShardedBot(command_prefix="p ", intents=intents)

@bot.event
async def on_ready():
    """Called when the bot is ready"""
    logger.info(f"Logged in as {bot.user}")
    print(f"Bot is ready! Logged in as {bot.user}")
    
    # Start the heartbeat task
    if not connection_heartbeat.is_running():
        connection_heartbeat.start()

@tasks.loop(minutes=5)
async def connection_heartbeat():
    """Maintains connection health and refreshes interaction cache"""
    logger.info("Connection heartbeat check...")
    try:
        # Perform basic activity to keep the connection active
        test_guild = None
        if bot.guilds:
            test_guild = bot.guilds[0]
            
        if test_guild:
            # Try to fetch basic data to keep the connection active
            await test_guild.fetch_channels()
    except Exception as e:
        logger.error(f"Error in heartbeat: {e}")

def run_bot():
    """Start the bot with error handling"""
    while True:
        try:
            # Import the main bot module for all the commands and functionality
            import bot as main_bot
            
            # Start the bot
            logger.info("Starting Discord bot...")
            bot.run(TOKEN)
        except discord.errors.LoginFailure:
            logger.error("Invalid Discord token. Please check your environment variables.")
            raise
        except Exception as e:
            logger.error(f"Bot crashed with error: {e}")
            logger.info("Attempting to restart the bot in 10 seconds...")
            time.sleep(10)

if __name__ == "__main__":
    run_bot()