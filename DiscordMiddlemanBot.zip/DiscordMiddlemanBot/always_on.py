#!/usr/bin/env python3
"""
Simple self-hosting script for Discord bot with keep-alive web server
"""
import os
import sys
import threading
from flask import Flask
from keep_alive import keep_alive
import bot

app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is alive!"

@app.route('/ping')
def ping():
    return "Pong! Bot is running."

def run_flask():
    """Run the Flask web server"""
    app.run(host='0.0.0.0', port=5000)

if __name__ == "__main__":
    print("Starting web server and Discord bot...")
    
    # Start both the keep_alive server and our backup server
    keep_alive()
    
    # Start our Flask server in a separate thread
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.daemon = True
    flask_thread.start()
    
    # Run the bot (this will block until the bot stops)
    bot.run_bot()