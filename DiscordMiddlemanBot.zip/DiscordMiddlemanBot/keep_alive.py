from flask import Flask, render_template_string
from threading import Thread
import os
import datetime
import platform

app = Flask('')

# HTML template for the homepage
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Discord Bot Status</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #2c2f33;
            color: #ffffff;
            margin: 0;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #23272a;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 {
            color: #7289da;
            text-align: center;
            margin-bottom: 30px;
        }
        .status {
            background-color: #2c2f33;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .online {
            color: #43b581;
            font-weight: bold;
        }
        .info-label {
            font-weight: bold;
            color: #7289da;
        }
        a {
            color: #7289da;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Halal Discord Bot Status</h1>
        <div class="status">
            <p><span class="online">● ONLINE</span> - Last checked: {{ time }}</p>
            <p><span class="info-label">Uptime:</span> {{ uptime }}</p>
            <p><span class="info-label">Host:</span> Replit</p>
            <p><span class="info-label">System:</span> {{ system }}</p>
        </div>
        <p>This page helps keep your Discord bot running 24/7. Bookmark this URL and set up a service like <a href="https://uptimerobot.com/" target="_blank">UptimeRobot</a> to ping it regularly.</p>
    </div>
</body>
</html>
"""

start_time = datetime.datetime.now()

@app.route('/')
def home():
    # Calculate uptime
    uptime = datetime.datetime.now() - start_time
    days, seconds = uptime.days, uptime.seconds
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    
    uptime_str = ""
    if days > 0:
        uptime_str += f"{days} days, "
    uptime_str += f"{hours} hours, {minutes} minutes, {seconds} seconds"
    
    # Render HTML with current status
    return render_template_string(
        HTML_TEMPLATE,
        time=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        uptime=uptime_str,
        system=platform.system() + " " + platform.release()
    )

@app.route('/ping')
def ping():
    return "Pong! Bot is alive and running!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.daemon = True  # Thread will close when main program exits
    t.start()
    print(f"Keep-alive server started at http://0.0.0.0:8080")