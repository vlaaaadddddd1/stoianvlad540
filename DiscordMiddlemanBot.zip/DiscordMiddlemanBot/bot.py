import discord
from discord.ext import commands
from discord.ui import View, Button, Select
import asyncio
import logging
import os
from dotenv import load_dotenv
import time
from datetime import datetime, timedelta
import random
import string
import sys

# Import the interaction error handler from middleware_fix
from middleware_fix import InteractionErrorHandler, ErrorHandlingCog
# Import keep_alive module to maintain 24/7 operation
from keep_alive import keep_alive

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('middleware_bot')

# Load environment variables if .env file exists
load_dotenv()

BLUE = "\033[94m"
RESET = "\033[0m"

# Logo URL for embed thumbnails
LOGO_URL = "https://i.imgur.com/ZyS3wLv.png"  # Replace with an actual hosted URL of the logo

print(f"{BLUE}"
      "$$$$$$$\\   $$$$$$\\  $$$$$$$\\  $$\\      $$\\ $$$$$$$$\\ $$$$$$$$\\  $$$$$$\\  $$\\   $$\\ \n"
      "$$  __$$\\ $$  __$$\\ $$  __$$\\ $$$\\    $$$ |$$  _____|\\__$$  __|$$  __$$\\ $$$\\  $$ |\n"
      "$$ |  $$ |$$ /  $$ |$$ |  $$ |$$$$\\  $$$$ |$$ |         $$ |   $$ /  $$ |$$$$\\ $$ |\n"
      "$$$$$$$\\ |$$$$$$$$ |$$ |  $$ |$$\\$$\\$$ $$ |$$$$$\\       $$ |   $$$$$$$$ |$$ $$\\$$ |\n"
      "$$  __$$\\ $$  __$$ |$$ |  $$ |$$ \\$$$  $$ |$$  __|      $$ |   $$  __$$ |$$ \\$$$$ |\n"
      "$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |\\$  /$$ |$$ |         $$ |   $$ |  $$ |$$ |\\$$$ |\n"
      "$$$$$$$  |$$ |  $$ |$$$$$$$  |$$ | \\_/ $$ |$$$$$$$$\\    $$ |   $$ |  $$ |$$ | \\$$ |\n"
      "\\_______/ \\__|  \\__|\\_______/ \\__|     \\__|\\________|   \\__|   \\__|  \\__|\\__|  \\__|\n"
      f"{RESET}")

# Get token from environment variable for security
TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = 1345169202117349456
ADMIN_ROLE_ID = 1359445037552898141
REQUIRED_ROLE_ID = 1357306728416280617
CATEGORY_ID = 1358553874855628984
CHANNEL_ID = 1358420202072576060

CRYPTO_CONFIG = {
    "BTC": {
        "name": "Bitcoin",
        "address": "bc1q086fm57za590gt0xcjqful5pt57d4nyfrnu7x5",
        "rate": 85000.00,
        "emoji_id": "1344677301383598173"
    },
    "ETH": {
        "name": "Ethereum",
        "address": "0x25c172a43D8Fddc52e97031E7d10861625842411",
        "rate": 2100.00,
        "emoji_id": "1160945873652547584"
    },
    "LTC": {
        "name": "Litecoin",
        "address": "LV3rCcPZEAQKY7rBNEjaNPrUBfj7wdUUQP",
        "rate": 95.43,
        "emoji_id": "1344678874549850163"
    },
    "SOL": {
        "name": "Solana",
        "address": "99GWHHq5tKL3Qo96wpQWVH3tt6tGEcUdkKSTfyKZVEjG",
        "rate": 150.20,
        "emoji_id": "1344678838650798091"
    }
}

# Theme color schemes
# Dark Mode (Default)
DARK_THEME = {
    "GREEN": discord.Color.from_rgb(0, 179, 89),  # Crypto green
    "RED": discord.Color.from_rgb(231, 76, 60),   # Crypto red
    "BLUE": discord.Color.from_rgb(52, 152, 219), # Bitcoin blue
    "YELLOW": discord.Color.from_rgb(241, 196, 15), # Bitcoin gold
    "BACKGROUND": discord.Color.from_rgb(24, 26, 32), # Dark background
    "TEXT": discord.Color.from_rgb(255, 255, 255), # White text
    "NAME": "Dark Mode"
}

# Light Mode
LIGHT_THEME = {
    "GREEN": discord.Color.from_rgb(46, 204, 113), # Lighter green
    "RED": discord.Color.from_rgb(235, 87, 87),    # Lighter red
    "BLUE": discord.Color.from_rgb(85, 172, 238),  # Lighter blue
    "YELLOW": discord.Color.from_rgb(247, 220, 111), # Lighter gold
    "BACKGROUND": discord.Color.from_rgb(240, 240, 240), # Light background
    "TEXT": discord.Color.from_rgb(44, 62, 80),     # Dark text
    "NAME": "Light Mode"
}

# Bitcoin Theme
BITCOIN_THEME = {
    "GREEN": discord.Color.from_rgb(247, 147, 26),  # Bitcoin orange
    "RED": discord.Color.from_rgb(140, 30, 21),     # Bitcoin dark red
    "BLUE": discord.Color.from_rgb(244, 146, 33),   # Bitcoin gold
    "YELLOW": discord.Color.from_rgb(242, 169, 0),  # Bitcoin yellow
    "BACKGROUND": discord.Color.from_rgb(29, 29, 29), # Dark background
    "TEXT": discord.Color.from_rgb(255, 193, 7),    # Gold text
    "NAME": "Bitcoin Theme"
}

# Ethereum Theme
ETHEREUM_THEME = {
    "GREEN": discord.Color.from_rgb(98, 126, 234),  # Ethereum blue
    "RED": discord.Color.from_rgb(211, 33, 66),     # Ethereum red
    "BLUE": discord.Color.from_rgb(40, 47, 82),     # Ethereum dark blue
    "YELLOW": discord.Color.from_rgb(200, 200, 200), # Ethereum silver
    "BACKGROUND": discord.Color.from_rgb(21, 27, 49), # Dark blue background
    "TEXT": discord.Color.from_rgb(152, 175, 237),   # Light blue text
    "NAME": "Ethereum Theme"
}

# User preferences dictionary to store theme preferences
user_preferences = {}

# Default theme
DEFAULT_THEME = DARK_THEME

# Currently active theme
active_theme = DEFAULT_THEME

# Shorthand colors for backward compatibility
GREEN_COLOR = active_theme["GREEN"]
RED_COLOR = active_theme["RED"]

intents = discord.Intents.default()
intents.guilds = True
intents.guild_messages = True
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix="p ", intents=intents)

# Add a command event listener to debug command processing
@bot.event
async def on_message(message):
    # Don't respond to our own messages
    if message.author == bot.user:
        return
    
    # Check if the message starts with our command prefix
    if message.content.startswith("p "):
        print(f"{BLUE}Command received: {message.content} from {message.author}{RESET}")
        logger.info(f"Command received: {message.content} from {message.author}")
    
    # Process commands as usual
    await bot.process_commands(message)

async def safe_delete(message):
    try:
        await message.delete()
    except discord.errors.NotFound:
        pass
    except Exception as e:
        logger.error(f"Error deleting message: {e}")

# --------------------------- [Close Button] ---------------------------------------------------------------------------------------------------------

class CloseButton(View):
    def __init__(self):
        super().__init__(timeout=None)  # No timeout for close buttons

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.red, custom_id="close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: Button):
        await InteractionErrorHandler.safe_respond(interaction, 
                       content="🗑️ This ticket will be deleted in 5 seconds.",
                       ephemeral=True)
        await asyncio.sleep(5)
        try:
            await interaction.channel.delete()
        except Exception as e:
            logger.error(f"Error deleting channel: {e}")
            await interaction.followup.send("Failed to delete the channel. Please try again or contact an administrator.", ephemeral=True)

# --------------------------- [ Role Assignment ] ---------------------------------------------------------------------------------------------------------

class RoleAssignment(View):
    def __init__(self, crypto_type):
        super().__init__(timeout=None)  # No timeout to prevent button failures
        self.sender = None
        self.receiver = None
        self.crypto_type = crypto_type
        self.role_message = None 
        self.update_in_progress = False

    async def send_initial_embed(self, interaction):
        try:
            # Get user theme if this is an interaction, otherwise use default
            user_id = interaction.user.id if hasattr(interaction, 'user') else None
            theme = get_user_theme(user_id) if user_id else DEFAULT_THEME
            
            # Create embed with green line on left side
            embed = discord.Embed(
                title="👥 Role Assignment",
                description="🔄 Select one of the following buttons that corresponds to your role in this deal.\n✅ Once selected, both users must confirm to proceed.",
                color=theme["GREEN"]
            )
            # Add logo to embed
            embed = add_logo_to_embed(embed)
            # Add a blank field to create the layout spacing
            embed.add_field(name="\u200b", value="\u200b", inline=False)
            # Add sender and receiver info
            embed.add_field(name="Sender", value="None", inline=True)
            embed.add_field(name="Receiver", value="None", inline=True)
            embed.set_footer(text="The ticket will be closed in 30 minutes if left unattended")

            # Check if we're dealing with an Interaction or a channel
            if hasattr(interaction, 'channel'):
                # This is either an interaction object or has a channel attribute
                channel = interaction.channel
            else:
                # Assume this is a Channel object directly
                channel = interaction
                
            # Send the message directly to the channel
            self.role_message = await channel.send(embed=embed, view=self)
            return self.role_message
        except Exception as e:
            logger.error(f"Error in send_initial_embed: {e}")
            # Try to respond with error in the appropriate way
            if hasattr(interaction, 'response') and hasattr(interaction, 'followup'):
                await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred while setting up roles: {e}", ephemeral=True)
            elif hasattr(interaction, 'send'):
                await interaction.send(f"An error occurred while setting up roles: {e}")

    async def update_embed(self, interaction):
        if self.update_in_progress:
            return  # Prevent concurrent updates
        
        self.update_in_progress = True
        try:
            # Get user theme if interaction has a user, otherwise use default
            user_id = interaction.user.id if hasattr(interaction, 'user') else None
            theme = get_user_theme(user_id) if user_id else DEFAULT_THEME
            
            embed = discord.Embed(
                title="👥 Role Assignment", 
                description="🔄 Select one of the following buttons that corresponds to your role in this deal.\n✅ Once selected, both users must confirm to proceed.", 
                color=theme["GREEN"]
            )
            # Add logo to embed
            embed = add_logo_to_embed(embed)
            # Add a blank field to create the layout spacing
            embed.add_field(name="\u200b", value="\u200b", inline=False)
            # Get the formatted user values
            sender_value = f"@{self.sender.name}" if self.sender else "None"
            receiver_value = f"@{self.receiver.name}" if self.receiver else "None"
            
            # Use simple text without animated emojis
            embed.add_field(name="Sender", value=sender_value, inline=True)
            embed.add_field(name="Receiver", value=receiver_value, inline=True)
            embed.set_footer(text="The ticket will be closed in 30 minutes if left unattended")
            
            # Update button states based on selected roles
            for child in self.children:
                if isinstance(child, Button):
                    if child.custom_id == "sender":
                        child.disabled = bool(self.sender)
                    elif child.custom_id == "receiver":
                        child.disabled = bool(self.receiver)
            
            # Store the message reference if not already stored
            if not self.role_message:
                if isinstance(interaction.message, discord.Message):
                    self.role_message = interaction.message
                else:
                    # In case the interaction.message is not a proper message reference
                    await InteractionErrorHandler.safe_respond(interaction, defer=True)
                    self.role_message = await interaction.channel.send(embed=embed, view=self)
                    return  # Skip the edit since we just sent a new message
            
            # Edit the message with updated information
            await self.role_message.edit(embed=embed, view=self)
            
            if self.sender and self.receiver:
                await asyncio.sleep(1)
                
                if self.role_message:
                    await safe_delete(self.role_message)
                
                # Create role confirmation instance
                role_confirm = RoleConfirmation(self.sender, self.receiver, self.crypto_type)
                
                # Send the confirmation message
                role_confirm.role_confirmation_message = await interaction.channel.send(
                    embed=self.get_confirmation_embed(), 
                    view=role_confirm
                )
        except Exception as e:
            logger.error(f"Error in update_embed: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred while updating roles: {e}", ephemeral=True)
        finally:
            self.update_in_progress = False

    def get_confirmation_embed(self):
        # Use sender's theme if available, otherwise default
        theme = get_user_theme(self.sender.id) if self.sender else DEFAULT_THEME
        
        confirmation_embed = discord.Embed(
            title="Role Confirmation", 
            description="Both roles are assigned. Please confirm to proceed with the transaction.", 
            color=theme["GREEN"]
        )
        # Add logo to embed
        confirmation_embed = add_logo_to_embed(confirmation_embed)
        # Add a blank field to create the layout spacing
        confirmation_embed.add_field(name="\u200b", value="\u200b", inline=False)
        # Get the formatted user values
        sender_value = f"@{self.sender.name}" if self.sender else "None"
        receiver_value = f"@{self.receiver.name}" if self.receiver else "None"
        
        # Use simple text without animated emojis
        confirmation_embed.add_field(name="Sender", value=sender_value, inline=True)
        confirmation_embed.add_field(name="Receiver", value=receiver_value, inline=True)
        return confirmation_embed

    @discord.ui.button(label="Sender", style=discord.ButtonStyle.grey, custom_id="sender")
    async def sender_button(self, interaction: discord.Interaction, button: Button):
        try:
            if interaction.user == self.receiver:
                await InteractionErrorHandler.safe_respond(interaction, content="You cannot be both sender and receiver!", ephemeral=True)
                return
            
            self.sender = interaction.user
            
            # Defer the response since we'll update the message
            await InteractionErrorHandler.safe_respond(interaction, defer=True, ephemeral=True)
            
            # Let the user know their role is being assigned
            await interaction.followup.send("You are now assigned as the Sender", ephemeral=True)
            
            # Update the embed with new role information
            await self.update_embed(interaction)
        except Exception as e:
            logger.error(f"Error in sender_button: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)

    @discord.ui.button(label="Receiver", style=discord.ButtonStyle.grey, custom_id="receiver")
    async def receiver_button(self, interaction: discord.Interaction, button: Button):
        try:
            # First respond to the interaction
            await InteractionErrorHandler.safe_respond(interaction, content="You selected receiver. Sending money will result in losing funds.", ephemeral=True)
            
            if interaction.user == self.sender:
                await interaction.followup.send("You cannot be both sender and receiver!", ephemeral=True)
                return
            
            self.receiver = interaction.user
            # Update the embed with new role information
            await self.update_embed(interaction)
        except Exception as e:
            logger.error(f"Error in receiver_button: {e}")
            # Try to respond if we haven't already
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)

    @discord.ui.button(label="Reset", style=discord.ButtonStyle.red, custom_id="reset")
    async def reset_button(self, interaction: discord.Interaction, button: Button):
        try:
            self.sender = None
            self.receiver = None
            
            # Defer the response since we'll update the message
            await InteractionErrorHandler.safe_respond(interaction, defer=True, ephemeral=True)
            
            # Let the user know roles have been reset
            await interaction.followup.send("Roles have been reset", ephemeral=True)
            
            # Update the embed with reset roles
            await self.update_embed(interaction)
        except Exception as e:
            logger.error(f"Error in reset_button: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)

# --------------------------- [ RoleConfirmation ] ---------------------------------------------------------------------------------------------------------

class RoleConfirmation(View):
    def __init__(self, sender, receiver, crypto_type):
        super().__init__(timeout=None)  # No timeout to prevent button failures
        self.confirmed_users = set()
        self.sender = sender
        self.receiver = receiver
        self.crypto_type = crypto_type
        self.confirmation_messages = []
        self.amount_confirmed = False
        self.amount_embed_message = None  
        self.role_confirmation_message = None
        self.confirm_in_progress = False

        self.user_confirmed = {
            sender.id: False,
            receiver.id: False
        }

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.green, custom_id="confirm_role")
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        if self.confirm_in_progress:
            await InteractionErrorHandler.safe_respond(interaction, content="Processing previous confirmation, please wait...", ephemeral=True)
            return
            
        self.confirm_in_progress = True
        
        try:
            if interaction.user.id not in self.user_confirmed:
                await InteractionErrorHandler.safe_respond(interaction, content="You are not part of this trade!", ephemeral=True)
                return

            if self.user_confirmed[interaction.user.id]:
                await InteractionErrorHandler.safe_respond(interaction, content="You have already confirmed your role!", ephemeral=True)
                return

            # Mark the user as confirmed
            self.user_confirmed[interaction.user.id] = True
            self.confirmed_users.add(interaction.user.id)

            # Store message reference if needed
            if self.role_confirmation_message is None:
                self.role_confirmation_message = interaction.message

            # Defer the interaction to prevent timeouts
            await InteractionErrorHandler.safe_respond(interaction, defer=True)

            # Get user theme
            theme = get_user_theme(interaction.user.id)
            
            # Send confirmation message
            confirm_embed = discord.Embed(description=f"{interaction.user.mention} has confirmed their role.", color=theme["GREEN"])
            confirm_message = await interaction.followup.send(embed=confirm_embed)
            self.confirmation_messages.append(confirm_message)

            # If both users confirmed, proceed to amount input
            if len(self.confirmed_users) == 2:
                await asyncio.sleep(2)

                # Clean up confirmation messages
                for msg in self.confirmation_messages:
                    await safe_delete(msg)

                # Clean up the role confirmation message if it exists
                if self.role_confirmation_message:
                    await safe_delete(self.role_confirmation_message)
                    self.role_confirmation_message = None  # Clear reference after deletion

                if not self.amount_confirmed:
                    self.amount_confirmed = True  # Prevent duplicate amount requests
                    
                    # Get user theme
                    theme = get_user_theme(self.sender.id)

                    # Ask for trade amount
                    amount_embed = discord.Embed(
                        title="Deal Amount",
                        description="State the amount in USD that you want to exchange (e.g., 100.59)\n\nJust type the number with or without the $ sign",
                        color=theme["GREEN"]
                    )
                    # Add logo to embed
                    amount_embed = add_logo_to_embed(amount_embed)
                    amount_embed.set_footer(text="Ticket will be closed in 30 minutes if left unattended")
                    self.amount_embed_message = await interaction.channel.send(f"{self.sender.mention}", embed=amount_embed)

                    def check(m):
                        # Check for proper amount format
                        content = m.content.replace('$', '', 1).strip()
                        return (m.author == self.sender and
                                m.channel == interaction.channel and
                                content.replace('.', '', 1).isdigit() and content.count('.') <= 1)

                    try:
                        amount_msg = await interaction.client.wait_for("message", timeout=120.0, check=check)

                        # Delete the amount embed message after sender inputs amount
                        await safe_delete(self.amount_embed_message)

                        amount = amount_msg.content.strip()
                        if not amount.startswith('$'):
                            amount = f"${amount}"

                        # Get sender's theme
                        theme = get_user_theme(self.sender.id)
                        
                        confirmation_embed = discord.Embed(
                            title="Amount Confirmation",
                            description=f"Both sender ({self.sender.mention}) and receiver ({self.receiver.mention}) must confirm that the following USD value is correct for this transaction",
                            color=theme["GREEN"]
                        )
                        # Add logo to embed
                        confirmation_embed = add_logo_to_embed(confirmation_embed)
                        confirmation_embed.add_field(name="Amount", value=amount, inline=False)

                        # Transition to AmountConfirmation view
                        await interaction.channel.send(
                            embed=confirmation_embed,
                            view=AmountConfirmation(self.sender, self.receiver, amount, self.crypto_type)
                        )

                    except asyncio.TimeoutError:
                        # Get sender's theme for consistent color usage
                        theme = get_user_theme(self.sender.id)
                        
                        await interaction.channel.send(
                            embed=discord.Embed(
                                description="❌ No amount was provided within the time limit. Please try again.",
                                color=theme["RED"]
                            )
                        )
                        await safe_delete(self.amount_embed_message)
                        
        except Exception as e:
            logger.error(f"Error in confirm_button: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)
        finally:
            self.confirm_in_progress = False

# Helper functions for theme management
def update_theme(user_id, theme_name):
    """
    Updates the active theme for a user
    
    Args:
        user_id: The Discord user ID
        theme_name: The name of the theme to set (dark, light, bitcoin, ethereum)
    
    Returns:
        The theme that was set
    """
    global user_preferences
    
    # Get the theme object based on the name
    if theme_name.lower() == "dark":
        theme = DARK_THEME
    elif theme_name.lower() == "light":
        theme = LIGHT_THEME
    elif theme_name.lower() == "bitcoin":
        theme = BITCOIN_THEME
    elif theme_name.lower() == "ethereum":
        theme = ETHEREUM_THEME
    else:
        theme = DEFAULT_THEME
    
    # Store the user's preference
    user_preferences[user_id] = theme
    
    return theme

def get_user_theme(user_id):
    """
    Gets the active theme for a user
    
    Args:
        user_id: The Discord user ID
    
    Returns:
        The active theme for the user or the default theme
    """
    global user_preferences
    
    # Return the user's preferred theme or the default
    return user_preferences.get(user_id, DEFAULT_THEME)

def get_theme_color(user_id, color_name):
    """
    Gets a specific color from a user's active theme
    
    Args:
        user_id: The Discord user ID
        color_name: The name of the color to get (GREEN, RED, BLUE, etc.)
    
    Returns:
        discord.Color object
    """
    theme = get_user_theme(user_id)
    return theme.get(color_name, DEFAULT_THEME[color_name])

def add_logo_to_embed(embed):
    """
    This function previously added the logo thumbnail to embeds.
    Now it just returns the embed as-is (removing logo functionality).
    
    Args:
        embed: The discord.Embed object
    
    Returns:
        The same embed without modification
    """
    # Logo functionality removed as requested
    return embed

# --------------------------- [ AmountConfirmation ] ---------------------------------------------------------------------------------------------------------

class AmountConfirmation(View):
    def __init__(self, sender, receiver, amount, crypto_type):
        super().__init__(timeout=None)  # No timeout to prevent button failures
        self.sender = sender
        self.receiver = receiver
        self.amount = amount
        self.crypto_type = crypto_type
        self.crypto_info = CRYPTO_CONFIG[crypto_type]
        self.confirmation_message = None
        self.confirm_in_progress = False
        self.confirmed_users = set()
        
        # Track confirmation status for both users
        self.user_confirmed = {
            sender.id: False,
            receiver.id: False
        }

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.green, custom_id="confirm_amount")
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        if self.confirm_in_progress:
            await InteractionErrorHandler.safe_respond(interaction, content="Processing previous request, please wait...", ephemeral=True)
            return
            
        self.confirm_in_progress = True
        
        try:
            # Only sender and receiver can confirm the amount
            if interaction.user != self.sender and interaction.user != self.receiver:
                await InteractionErrorHandler.safe_respond(interaction, content="Only participants in this trade can confirm the amount.", ephemeral=True)
                return
            
            # Check if user already confirmed
            if self.user_confirmed[interaction.user.id]:
                await InteractionErrorHandler.safe_respond(interaction, content="You have already confirmed this amount.", ephemeral=True)
                return
                
            # Mark user as confirmed
            self.user_confirmed[interaction.user.id] = True
            self.confirmed_users.add(interaction.user.id)
            
            # Get user theme
            theme = get_user_theme(interaction.user.id)
            
            # Acknowledge the confirmation
            await InteractionErrorHandler.safe_respond(interaction, defer=True)
            
            # Let everyone know this user confirmed
            confirm_embed = discord.Embed(
                description=f"{interaction.user.mention} has confirmed the amount.",
                color=theme["GREEN"]
            )
            await interaction.followup.send(embed=confirm_embed)
            
            # If both users have confirmed, proceed to payment view
            if len(self.confirmed_users) == 2:
                # Parse the amount value (remove $ and convert to float)
                amount_value = float(self.amount.replace('$', '').strip())
                
                # Calculate cryptocurrency amount based on the rate
                crypto_amount = amount_value / self.crypto_info['rate']
                formatted_crypto_amount = f"{crypto_amount:.8f}"
                
                # Store message reference if needed
                if self.confirmation_message is None:
                    self.confirmation_message = interaction.message
                    
                # Clean up the amount confirmation message
                if self.confirmation_message:
                    await safe_delete(self.confirmation_message)
                    
                # Create payment view
                payment_view = PaymentView(
                    self.sender, 
                    self.receiver, 
                    self.crypto_type, 
                    formatted_crypto_amount, 
                    self.amount
                )
                
                # Get user theme
                theme = get_user_theme(self.sender.id)
                
                # Send payment information
                payment_embed = discord.Embed(
                    title="Payment Invoice",
                    description=f"Please send the funds to the secure Middleman address below.\n\nMake sure to send the exact amount specified.",
                    color=theme["GREEN"]
                )
                # Add logo to embed
                payment_embed = add_logo_to_embed(payment_embed)
                
                # Add QR code or relevant crypto details
                payment_embed.add_field(name="Address", value=f"`{self.crypto_info['address']}`", inline=False)
                payment_embed.add_field(name="Amount", value=f"`{formatted_crypto_amount} {self.crypto_type} (${amount_value:.2f} USD)`", inline=False)
                payment_embed.add_field(name="Exchange Rate", value=f"1 {self.crypto_type} = ${self.crypto_info['rate']:.2f} USD", inline=False)
                
                # Send summary embed
                summary_embed = discord.Embed(
                    title="Deal Summary",
                    description="Below are the details of your transaction. Please review the information carefully.\n\nIf you need assistance, notify staff for support.",
                    color=theme["GREEN"]
                )
                # Add logo to embed
                summary_embed = add_logo_to_embed(summary_embed)
                summary_embed.add_field(name="Sender", value=f"{self.sender.mention}", inline=True)
                summary_embed.add_field(name="Receiver", value=f"{self.receiver.mention}", inline=True)
                summary_embed.add_field(name="Deal Value", value=self.amount, inline=True)
                summary_embed.add_field(name="Coin", value=f"{self.crypto_info['name']} ({self.crypto_type})", inline=True)
                summary_embed.add_field(name="Fee", value="FREE", inline=True)
                
                await interaction.channel.send(embed=summary_embed)
                
                # Create the initial payment message with an empty view
                payment_message = await interaction.channel.send(embed=payment_embed)
                
                # Store the message reference for future updates
                payment_view.payment_message = payment_message
                
                # Create and set custom views for both sender and receiver
                # This ensures only the sender can see the payment button
                sender_view = await payment_view.get_user_specific_view(self.sender)
                await payment_message.edit(view=sender_view)
            
        except Exception as e:
            logger.error(f"Error in confirm_amount_button: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)
        finally:
            self.confirm_in_progress = False

# --------------------------- [ PaymentView ] ---------------------------------------------------------------------------------------------------------

class PaymentView(View):
    def __init__(self, sender, receiver, crypto_type, crypto_amount, usd_amount):
        super().__init__(timeout=None)  # No timeout to prevent button failures
        self.sender = sender
        self.receiver = receiver
        self.crypto_type = crypto_type
        self.crypto_amount = crypto_amount
        self.usd_amount = usd_amount
        self.crypto_info = CRYPTO_CONFIG[crypto_type]
        self.payment_message = None
        self.operation_in_progress = False
        self.transaction_detected = False
        
    # Custom view builder that shows specific buttons based on user
    async def get_user_specific_view(self, user):
        """Create a custom view instance with buttons specific to the user"""
        # Create a new view with the same timeout
        user_view = View(timeout=None)
        
        # Add copy details button for everyone
        copy_button = Button(label="Copy Details", style=discord.ButtonStyle.grey, custom_id="copy_details")
        # Wrap the callback to ensure it gets the needed 'button' parameter
        copy_button.callback = lambda interaction: self.copy_details(interaction, copy_button)
        user_view.add_item(copy_button)
        
        # Add "I've Sent the Payment" button only for the sender
        if user == self.sender:
            payment_button = Button(label="I've Sent the Payment", style=discord.ButtonStyle.green, custom_id="transaction_sent")
            # Wrap the callback to ensure it gets the needed 'button' parameter
            payment_button.callback = lambda interaction: self.transaction_sent(interaction, payment_button)
            user_view.add_item(payment_button)
            
        return user_view

    # This method is called programmatically through the custom view
    async def copy_details(self, interaction: discord.Interaction, button: Button):
        try:
            details = f"Address: {self.crypto_info['address']}\nAmount: {self.crypto_amount} {self.crypto_type}"
            await InteractionErrorHandler.safe_respond(interaction, content=f"```{details}```", ephemeral=True)
            
            # Store message reference if needed
            if self.payment_message is None:
                self.payment_message = interaction.message
            
            # If this is not the sender viewing the message, update the view with appropriate buttons
            if interaction.user == self.receiver and self.payment_message:
                # Get a receiver-specific view with just the copy button (no payment button)
                receiver_view = await self.get_user_specific_view(self.receiver)
                await self.payment_message.edit(view=receiver_view)
            elif interaction.user == self.sender and self.payment_message:
                # Get a sender-specific view with both buttons
                sender_view = await self.get_user_specific_view(self.sender)
                await self.payment_message.edit(view=sender_view)
                
            # Start transaction detection in the background if not already started
            if not self.transaction_detected:
                # Start the transaction detection process (simulate detection after a delay)
                interaction.client.loop.create_task(self.detect_transaction(interaction.channel))
                
        except Exception as e:
            logger.error(f"Error in copy_details: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)

    # Background transaction detection (simulates real blockchain monitoring)
    async def detect_transaction(self, channel):
        """Simulate detecting a transaction on the blockchain (in reality would query API)"""
        # This method doesn't do anything yet, but could be used in the future
        # for automated transaction detection via blockchain API integration
        pass
        
    # For manual transaction verification
    # This method is called programmatically through the custom view
    async def transaction_sent(self, interaction: discord.Interaction, button: Button):
        """Allows the sender to indicate they have sent a payment, requiring transaction ID verification"""
        try:
            # Only the sender can use this button
            if interaction.user != self.sender:
                await InteractionErrorHandler.safe_respond(interaction, content="Only the sender can mark a payment as sent.", ephemeral=True)
                return
            
            # Store message reference if needed
            if self.payment_message is None:
                self.payment_message = interaction.message
                
            # Get user theme
            theme = get_user_theme(self.sender.id)
            
            # Ask for a transaction ID
            transaction_prompt = discord.Embed(
                title="Transaction Verification",
                description=f"Please provide the transaction ID/hash from your {self.crypto_type} transaction.",
                color=theme["GREEN"]
            )
            # Add logo to embed
            transaction_prompt = add_logo_to_embed(transaction_prompt)
            transaction_prompt.add_field(
                name="Important Note", 
                value="The transaction ID is required to verify your payment was actually sent. You can find this in your wallet after sending funds.",
                inline=False
            )
            
            await InteractionErrorHandler.safe_respond(interaction, embed=transaction_prompt, ephemeral=True)
            
            # Set up a listener for the transaction ID
            def check_txid(message):
                # Make sure message is from the sender
                return message.author.id == self.sender.id and message.channel.id == interaction.channel.id
                
            # Let them know we're waiting for their transaction ID
            await interaction.channel.send(f"{self.sender.mention}, please provide the transaction ID/hash for your {self.crypto_type} payment.")
            
            # Wait for the transaction ID to be provided
            try:
                # Wait for the sender to paste the transaction ID in the channel
                message = await interaction.client.wait_for('message', check=check_txid, timeout=300)
                transaction_id = message.content.strip()
                
                # Transaction received - now we can mark it as verified
                await self.verify_transaction(interaction.channel, transaction_id)
                
            except asyncio.TimeoutError:
                await interaction.channel.send(f"{self.sender.mention}, no transaction ID was provided. Please try again by clicking the 'I've Sent the Payment' button.")
                
        except Exception as e:
            logger.error(f"Error in transaction_sent: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)

    # Transaction verification process
    async def verify_transaction(self, channel, transaction_id):
        """Verify a transaction ID and display the release button if valid"""
        try:
            # In a real implementation, this would query the blockchain API to verify the transaction
            # For now, we'll simply accept any transaction ID that looks reasonable
            if len(transaction_id) < 10:  # Arbitrary minimum length check
                await channel.send(f"⚠️ The transaction ID provided seems too short to be valid. Please check and try again.")
                return
            
            # Transaction verified!
            self.transaction_detected = True
            
            # Get sender's theme
            theme = get_user_theme(self.sender.id)
            
            # Mark transaction as verified
            verification_embed = discord.Embed(
                title="Transaction Verified!",
                description=f"The {self.crypto_type} transaction has been recorded with ID: `{transaction_id}`",
                color=theme["GREEN"]
            )
            # Add logo to embed
            verification_embed = add_logo_to_embed(verification_embed)
            verification_embed.add_field(
                name="Transaction Details", 
                value=f"Amount: {self.crypto_amount} {self.crypto_type}\nSender: {self.sender.mention}\nStatus: Verified ✓",
                inline=False
            )
            verification_embed.add_field(
                name="Next Step", 
                value=f"{self.sender.mention} needs to click the **Release Funds** button to complete this transaction.",
                inline=False
            )
            
            # Add blockchain explorer link if applicable
            if self.crypto_type in ["BTC", "ETH", "LTC", "SOL"]:
                explorer_url = self.get_explorer_url(transaction_id)
                verification_embed.add_field(
                    name="View Transaction", 
                    value=f"[View on Blockchain Explorer]({explorer_url})",
                    inline=False
                )
            
            # Send the verification notification
            await channel.send(embed=verification_embed)
            
            # Add the Release button for the sender
            release_view = ReleaseView(
                self.sender, 
                self.receiver, 
                self.crypto_type, 
                self.crypto_amount, 
                self.usd_amount
            )
            
            # Use the same theme for consistency
            release_embed = discord.Embed(
                title="Release Funds",
                description=f"The payment of {self.crypto_amount} {self.crypto_type} has been verified.\n\n{self.sender.mention}, please click the **Release Funds** button to complete the transaction.",
                color=theme["GREEN"]
            )
            # Add logo to embed
            release_embed = add_logo_to_embed(release_embed)
            
            await channel.send(embed=release_embed, view=release_view)
            
        except Exception as e:
            logger.error(f"Error in verify_transaction: {e}")
            await channel.send(f"Error verifying transaction: {e}")
    
    # Helper method to get blockchain explorer URL
    def get_explorer_url(self, tx_id):
        """Generate the blockchain explorer URL for a given transaction ID"""
        if self.crypto_type == "BTC":
            return f"https://www.blockchain.com/btc/tx/{tx_id}"
        elif self.crypto_type == "ETH":
            return f"https://etherscan.io/tx/{tx_id}"
        elif self.crypto_type == "LTC":
            return f"https://blockchair.com/litecoin/transaction/{tx_id}"
        elif self.crypto_type == "SOL":
            return f"https://explorer.solana.com/tx/{tx_id}"
        else:
            return "#"  # Fallback if no explorer is available
            
# Release button view that appears after transaction detection
class ReleaseView(View):
    def __init__(self, sender, receiver, crypto_type, crypto_amount, usd_amount):
        super().__init__(timeout=None)  # No timeout to prevent button failures
        self.sender = sender
        self.receiver = receiver
        self.crypto_type = crypto_type
        self.crypto_amount = crypto_amount
        self.usd_amount = usd_amount

    @discord.ui.button(label="Release Funds", style=discord.ButtonStyle.green, custom_id="release_funds")
    async def release_funds(self, interaction: discord.Interaction, button: Button):
        try:
            # Only the sender can release funds
            if interaction.user != self.sender:
                await InteractionErrorHandler.safe_respond(interaction, content="Only the sender can release funds to the receiver.", ephemeral=True)
                return
                
            # Disable all buttons
            for child in self.children:
                child.disabled = True
                
            # Update the message
            await interaction.message.edit(view=self)
            
            # Respond to the interaction
            await InteractionErrorHandler.safe_respond(interaction, content="You've released the funds to the receiver. The transaction is now complete.", ephemeral=True)
            
            # Get sender theme for consistent UI
            theme = get_user_theme(self.sender.id)
            
            # Send success message
            success_embed = discord.Embed(
                title="✅ Transaction Completed!",
                description=f"{self.sender.mention} has released {self.crypto_amount} {self.crypto_type} to {self.receiver.mention}.\n\nThe deal is now complete! Thank you for using our secure middleman service.",
                color=theme["GREEN"]
            )
            # Add logo to embed
            success_embed = add_logo_to_embed(success_embed)
            success_embed.add_field(name="Transaction Details", value=(
                f"**Amount:** {self.crypto_amount} {self.crypto_type} (${self.usd_amount})\n"
                f"**Sender:** {self.sender.mention}\n"
                f"**Receiver:** {self.receiver.mention}\n"
                f"**Status:** Complete ✅"
            ))
            
            await interaction.channel.send(embed=success_embed)
            
            # Add "Close Ticket" button to allow users to close the channel
            close_btn = CloseButton()
            close_embed = discord.Embed(
                description="Click the button below to close this ticket and archive the transaction records.",
                color=discord.Color.lighter_grey()
            )
            await interaction.channel.send(embed=close_embed, view=close_btn)
            
        except Exception as e:
            logger.error(f"Error in release_funds: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)
                    
            if self.payment_message:
                await self.payment_message.edit(view=self)
        finally:
            self.operation_in_progress = False

    @discord.ui.button(label="Cancel Transaction", style=discord.ButtonStyle.red, custom_id="cancel_transaction")
    async def cancel_transaction(self, interaction: discord.Interaction, button: Button):
        # Show confirmation prompt
        await InteractionErrorHandler.safe_respond(interaction, defer=True, ephemeral=True)
        await interaction.followup.send(
            content="Are you sure you want to cancel this transaction?",
            view=CancelConfirmation(self),
            ephemeral=True
        )

class CancelConfirmation(View):
    def __init__(self, payment_view):
        super().__init__(timeout=None)  # No timeout to prevent button failures
        self.payment_view = payment_view

    @discord.ui.button(label="Yes, Cancel", style=discord.ButtonStyle.red, custom_id="confirm_cancel")
    async def confirm_cancel(self, interaction: discord.Interaction, button: Button):
        try:
            # Disable all buttons in the original payment view
            for child in self.payment_view.children:
                if isinstance(child, Button):
                    child.disabled = True
                    
            # Update the original message if reference exists
            if self.payment_view.payment_message:
                await self.payment_view.payment_message.edit(view=self.payment_view)
                
            # Respond to the interaction
            await InteractionErrorHandler.safe_respond(interaction, content="Transaction cancelled.", ephemeral=True)
            
            # Get user theme
            theme = get_user_theme(interaction.user.id)
            
            # Send cancellation notification to channel
            cancellation_embed = discord.Embed(
                title="Transaction Cancelled",
                description=f"{interaction.user.mention} has cancelled the transaction.\n\nThis ticket can now be closed.",
                color=theme["RED"]
            )
            # Add logo to embed
            cancellation_embed = add_logo_to_embed(cancellation_embed)
            
            await interaction.channel.send(embed=cancellation_embed, view=CloseButton())
            
        except Exception as e:
            logger.error(f"Error in confirm_cancel: {e}")
            await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)

    @discord.ui.button(label="No, Continue", style=discord.ButtonStyle.green, custom_id="deny_cancel")
    async def deny_cancel(self, interaction: discord.Interaction, button: Button):
        await InteractionErrorHandler.safe_respond(interaction, content="Cancellation aborted. The transaction will continue.", ephemeral=True)

# --------------------------- [ Theme Selection ] ---------------------------------------------------------------------------------------------------------

# Theme selection view for the theme command
class ThemeSelectionView(View):
    def __init__(self, user_id):
        super().__init__(timeout=60)  # 60 second timeout
        self.user_id = user_id
        
    @discord.ui.button(label="Dark Mode", style=discord.ButtonStyle.secondary, custom_id="theme_dark")
    async def dark_theme_button(self, interaction: discord.Interaction, button: Button):
        # Only let the command user change their theme
        if interaction.user.id != self.user_id:
            await InteractionErrorHandler.safe_respond(interaction, content="This isn't your theme selection.", ephemeral=True)
            return
            
        # Set the user's theme to dark mode
        theme = update_theme(interaction.user.id, "dark")
        
        # Create a preview embed with the new theme colors
        embed = discord.Embed(
            title="Theme Updated",
            description=f"Your theme has been set to **{theme['NAME']}**",
            color=theme["GREEN"]
        )
        # Add logo to embed
        embed = add_logo_to_embed(embed)
        embed.add_field(name="Preview", value="This is how your embeds will look now", inline=False)
        embed.add_field(name="Primary Color", value="Used for main elements", inline=True)
        embed.add_field(name="Accent Color", value="Used for highlights", inline=True)
        
        # Disable all buttons
        for child in self.children:
            child.disabled = True
            
        # Update the message
        await interaction.message.edit(embed=embed, view=self)
        await InteractionErrorHandler.safe_respond(interaction, content="Theme updated to Dark Mode.", ephemeral=True)
        
    @discord.ui.button(label="Light Mode", style=discord.ButtonStyle.primary, custom_id="theme_light") 
    async def light_theme_button(self, interaction: discord.Interaction, button: Button):
        # Only let the command user change their theme
        if interaction.user.id != self.user_id:
            await InteractionErrorHandler.safe_respond(interaction, content="This isn't your theme selection.", ephemeral=True)
            return
            
        # Set the user's theme to light mode
        theme = update_theme(interaction.user.id, "light")
        
        # Create a preview embed with the new theme colors
        embed = discord.Embed(
            title="Theme Updated",
            description=f"Your theme has been set to **{theme['NAME']}**",
            color=theme["GREEN"]
        )
        # Add logo to embed
        embed = add_logo_to_embed(embed)
        embed.add_field(name="Preview", value="This is how your embeds will look now", inline=False)
        embed.add_field(name="Primary Color", value="Used for main elements", inline=True)
        embed.add_field(name="Accent Color", value="Used for highlights", inline=True)
        
        # Disable all buttons
        for child in self.children:
            child.disabled = True
            
        # Update the message
        await interaction.message.edit(embed=embed, view=self)
        await InteractionErrorHandler.safe_respond(interaction, content="Theme updated to Light Mode.", ephemeral=True)
        
    @discord.ui.button(label="Bitcoin Theme", style=discord.ButtonStyle.primary, custom_id="theme_bitcoin")
    async def bitcoin_theme_button(self, interaction: discord.Interaction, button: Button):
        # Only let the command user change their theme
        if interaction.user.id != self.user_id:
            await InteractionErrorHandler.safe_respond(interaction, content="This isn't your theme selection.", ephemeral=True)
            return
            
        # Set the user's theme to Bitcoin theme
        theme = update_theme(interaction.user.id, "bitcoin")
        
        # Create a preview embed with the new theme colors
        embed = discord.Embed(
            title="Theme Updated",
            description=f"Your theme has been set to **{theme['NAME']}**",
            color=theme["GREEN"]
        )
        # Add logo to embed
        embed = add_logo_to_embed(embed)
        embed.add_field(name="Preview", value="This is how your embeds will look now", inline=False)
        embed.add_field(name="Primary Color", value="Used for main elements", inline=True)
        embed.add_field(name="Accent Color", value="Used for highlights", inline=True)
        
        # Disable all buttons
        for child in self.children:
            child.disabled = True
            
        # Update the message
        await interaction.message.edit(embed=embed, view=self)
        await InteractionErrorHandler.safe_respond(interaction, content="Theme updated to Bitcoin Theme.", ephemeral=True)
        
    @discord.ui.button(label="Ethereum Theme", style=discord.ButtonStyle.primary, custom_id="theme_ethereum")
    async def ethereum_theme_button(self, interaction: discord.Interaction, button: Button):
        # Only let the command user change their theme
        if interaction.user.id != self.user_id:
            await InteractionErrorHandler.safe_respond(interaction, content="This isn't your theme selection.", ephemeral=True)
            return
            
        # Set the user's theme to Ethereum theme
        theme = update_theme(interaction.user.id, "ethereum")
        
        # Create a preview embed with the new theme colors
        embed = discord.Embed(
            title="Theme Updated",
            description=f"Your theme has been set to **{theme['NAME']}**",
            color=theme["GREEN"]
        )
        # Add logo to embed
        embed = add_logo_to_embed(embed)
        embed.add_field(name="Preview", value="This is how your embeds will look now", inline=False)
        embed.add_field(name="Primary Color", value="Used for main elements", inline=True)
        embed.add_field(name="Accent Color", value="Used for highlights", inline=True)
        
        # Disable all buttons
        for child in self.children:
            child.disabled = True
            
        # Update the message
        await interaction.message.edit(embed=embed, view=self)
        await InteractionErrorHandler.safe_respond(interaction, content="Theme updated to Ethereum Theme.", ephemeral=True)

@bot.command(name="theme", help="Change the visual theme of the bot")
async def theme_command(ctx):
    """Sets the visual theme for the bot's panels and embeds"""
    # Get the user's current theme
    current_theme = get_user_theme(ctx.author.id)
    
    # Create an embed to show the theme selection
    embed = discord.Embed(
        title="Theme Selection",
        description=f"Your current theme: **{current_theme['NAME']}**\nSelect a theme from the options below:",
        color=current_theme["GREEN"]
    )
    # Add logo to embed
    embed = add_logo_to_embed(embed)
    
    # Add preview info for each theme
    embed.add_field(name="Dark Mode", value="Default dark theme with green accents", inline=True)
    embed.add_field(name="Light Mode", value="Bright theme with soft colors", inline=True)
    embed.add_field(name="Bitcoin Theme", value="Bitcoin-inspired orange and gold", inline=True)
    embed.add_field(name="Ethereum Theme", value="Ethereum-inspired blue palette", inline=True)
    
    # Create the theme selection view
    view = ThemeSelectionView(ctx.author.id)
    
    # Send the theme selection message
    await ctx.send(embed=embed, view=view)

# --------------------------- [ Panel Command ] ---------------------------------------------------------------------------------------------------------

@bot.command(name="panel", help="Sets up the cryptocurrency selection panel.")
async def panel(ctx):
    """Sets up the cryptocurrency selection panel."""
    try:
        # Debug logging
        print(f"{BLUE}Panel command executed by {ctx.author} (ID: {ctx.author.id}){RESET}")
        logger.info(f"Panel command executed by {ctx.author} (ID: {ctx.author.id})")
        
        # Skip permission check - allow all users to create panels
        # Continue with panel creation
        
        # Create dropdown for crypto selection
        select = Select(
            placeholder="Make a selection",
            options=[
                discord.SelectOption(
                    label=CRYPTO_CONFIG[crypto]["name"],
                    value=crypto,
                    emoji=f"<:crypto:{CRYPTO_CONFIG[crypto]['emoji_id']}>" if CRYPTO_CONFIG[crypto]['emoji_id'] else None
                ) for crypto in ["BTC", "ETH", "LTC", "SOL"]  # Only include these specific cryptocurrencies
            ],
            custom_id="crypto_select"
        )
        
        # Create the view and add the select menu
        view = View(timeout=None)  # Panel should never time out
        view.add_item(select)
        
        # Set up the callback for the select menu
        async def callback(interaction):
            try:
                # Debug logging
                print(f"{BLUE}Dropdown selection made by {interaction.user} (ID: {interaction.user.id}){RESET}")
                logger.info(f"Dropdown selection made by {interaction.user} (ID: {interaction.user.id})")
                logger.info(f"Selection data: {interaction.data}")
                
                # Defer the response to avoid "Interaction Failed"
                await InteractionErrorHandler.safe_respond(interaction, defer=True, ephemeral=True)
                
                # Get selected crypto
                crypto = interaction.data['values'][0]
                user = interaction.user
                
                # Create or get the "cryptocurrency" category
                category_name = "cryptocurrency"
                category = discord.utils.get(interaction.guild.categories, name=category_name)
                if not category:
                    category = await interaction.guild.create_category(name=category_name)
                
                # Set channel permissions
                overwrites = {
                    interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                    user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                    discord.Object(ADMIN_ROLE_ID): discord.PermissionOverwrite(read_messages=True, send_messages=True)
                }
                
                # Create a new Halal service channel
                current_ticket_id = random.randint(100, 9999)
                channel = await interaction.guild.create_text_channel(
                    f"halal-service-{current_ticket_id}", 
                    category=category, 
                    overwrites=overwrites
                )
                
                # Send a follow-up message to the user
                await interaction.followup.send(
                    embed=discord.Embed(
                        title="Halal Service Created",
                        description=f"Halal service {channel.mention} created for {crypto}.",
                        color=GREEN_COLOR
                    ),
                    ephemeral=True
                )
                
                # Get user theme
                user_theme = get_user_theme(user.id)
                
                # Send welcome message in the ticket channel
                # Welcome message with theme-colored sidebar
                welcome_embed = discord.Embed(
                    title="Cryptocurrency Middleman System",
                    description=f"**{CRYPTO_CONFIG[crypto]['name']}** Middleman request created successfully!\n\nWelcome to our automated cryptocurrency Middleman system! Your cryptocurrency will be stored securely for the duration of this deal. Please notify support for assistance.",
                    color=user_theme["GREEN"]
                )
                # Add logo to embed
                welcome_embed = add_logo_to_embed(welcome_embed)
                # Add the service number (using channel name as reference)
                service_number = channel.name.split('-')[-1] if '-' in channel.name else "Unknown"
                welcome_embed.add_field(name="🎫 Halal Service", value=f"#{service_number}", inline=False)
                
                # Send welcome embed
                await channel.send(embed=welcome_embed)
                
                # Security notification with theme-appropriate red sidebar
                security_embed = discord.Embed(
                    title="Security Notification",
                    description="Our bot and staff team will **NEVER** direct message you.\n\nEnsure all conversations related to the deal are done within this Halal service channel.\n\nFailure to do so may put you at risk of being scammed.",
                    color=user_theme["RED"]
                )
                # Add logo to embed
                security_embed = add_logo_to_embed(security_embed)
                
                # Create a view with a close button
                close_btn = CloseButton()
                
                # Send security notification
                await channel.send(embed=security_embed, view=close_btn)
                
                # Ask who they're dealing with, using theme-specific color
                dealing_embed = discord.Embed(
                    title="Who are you dealing with?",
                    description="Tag a user: @username\nOr paste a user ID: 123456789123456789",
                    color=user_theme["GREEN"]
                )
                # Add logo to embed
                dealing_embed = add_logo_to_embed(dealing_embed)
                
                # Send the dealing with embed
                await channel.send(embed=dealing_embed)
                
                # Set up a listener for user IDs or mentions
                def check_user_message(message):
                    # Check if message is in the same channel and not from the bot
                    if message.channel.id != channel.id or message.author.bot:
                        return False
                    
                    content = message.content.strip()
                    
                    # Check for user mention
                    has_mention = len(message.mentions) > 0
                    
                    # Check for user ID (numeric string of appropriate length)
                    is_user_id = content.isdigit() and 17 <= len(content) <= 19
                    
                    # Check for username format (starting with @)
                    is_username = content.startswith('@') and len(content) > 1
                    
                    return has_mention or is_user_id or is_username
                
                # Create task to wait for user message
                bot.loop.create_task(wait_for_user_input(channel, interaction.guild, check_user_message))
                
                # Note: We're not initializing role assignment immediately anymore
                # It will be sent after a user is added to the ticket via wait_for_user_input
                
            except Exception as e:
                logger.error(f"Error in select callback: {e}")
                await InteractionErrorHandler.safe_respond(interaction, content=f"An error occurred: {e}", ephemeral=True)
        
        # Assign the callback
        select.callback = callback
        
        # Get the user's theme
        user_theme = get_user_theme(ctx.author.id)
        
        # Send the panel
        panel_embed = discord.Embed(
            title="Cryptocurrency Exchange",
            description="**Fees:**\nDeals $250+: 1%\nDeals under $250: $2\nDeals under $50 are FREE\n\nSelect a cryptocurrency below to initiate a secure transaction with our middleman service.",
            color=user_theme["GREEN"]
        )
        # Add logo to embed
        panel_embed = add_logo_to_embed(panel_embed)
        
        await ctx.send(embed=panel_embed, view=view)
        
    except Exception as e:
        logger.error(f"Error in panel command: {e}")
        await ctx.send(f"An error occurred: {e}")

# --------------------------- [ Terms of Service Command ] ---------------------------------------------------------------------------------------------------------

@bot.command(name="tos", help="Display the Terms of Service for the bot")
async def terms_of_service_command(ctx):
    """Displays the Terms of Service embed"""
    try:
        # Create the ToS embed with green sidebar like in the example
        tos_embed = discord.Embed(
            color=0x00FF00  # Brighter green color for the sidebar to match example
        )
        
        # Add timestamp to match the example
        tos_embed.timestamp = datetime.now()
        
        # Set author field to mimic the "Halal APP" header in the example (without logo as requested)
        tos_embed.set_author(name="Halal APP")

        # Main title
        tos_embed.add_field(
            name="Terms of Service",
            value="By using this service, you accept the [Discord ToS](https://discord.com/terms), and the following terms",
            inline=False
        )
        
        # Add User Liability section - using separate fields for title and content
        tos_embed.add_field(
            name="User Liability",
            value="While using this service, it is your duty to ensure that you are reading and acknowledging provided prompts. User errors are not insured, and will result in the loss of your cryptocurrency/valuables.", 
            inline=False
        )
        
        # Add Service Safety section
        tos_embed.add_field(
            name="Service Safety",
            value="If we perceive something as suspicious, or against the ToS, we have the authority to decline your request. Any deals involving gift cards, accounts, or unfamiliar content is prohibited.",
            inline=False
        )
        
        # Add Account Security section
        tos_embed.add_field(
            name="Account Security",
            value="While using this service, it is your responsibility to ensure the safety of your account. If your account is compromised, we are not liable for any losses.",
            inline=False
        )
        
        # Add User Guarantee section
        tos_embed.add_field(
            name="User Guarantee",
            value="By using this service, you are guaranteed the safety of your funds. All funds lost in our possession following a bot error will be compensated 1:1. User errors will not be compensated.",
            inline=False
        )
        
        # Set footer to show "Halal MM" as in the example (without logo as requested)
        tos_embed.set_footer(text="Halal MM")
        
        # Send the embed
        await ctx.send(embed=tos_embed)
        
    except Exception as e:
        logger.error(f"Error in terms_of_service command: {e}")
        await ctx.send(f"An error occurred: {e}")

# --------------------------- [ Close All Command ] ---------------------------------------------------------------------------------------------------------

@bot.command(name="closeall", help="Close all active Halal services (Admin only)")
async def closeall_command(ctx):
    """Closes all active Halal service channels"""
    try:
        # Check if the user has admin role or is the server owner
        is_admin = False
        # Server owner always has admin privileges
        if ctx.author.id == ctx.guild.owner_id:
            is_admin = True
        else:
            # Check for admin role
            admin_role = discord.utils.get(ctx.guild.roles, id=ADMIN_ROLE_ID)
            if admin_role and admin_role in ctx.author.roles:
                is_admin = True
        
        # If not an admin, return with error message
        if not is_admin:
            await ctx.send("You don't have permission to use this command. Only administrators can close all Halal services.")
            return
        
        # Look for all channels that match both the new "halal-service-*" and old "ticket-*" patterns
        halal_channels = [channel for channel in ctx.guild.channels 
                         if isinstance(channel, discord.TextChannel) 
                         and (channel.name.startswith("halal-service-") or channel.name.startswith("ticket-"))]
        
        if not halal_channels:
            await ctx.send("No active Halal services found.")
            return
        
        # Get user theme for embeds
        user_theme = get_user_theme(ctx.author.id)
        
        # Create confirmation embed
        confirmation_embed = discord.Embed(
            title="Closing All Halal Services",
            description=f"Found {len(halal_channels)} active Halal service(s). Closing all channels...",
            color=user_theme["GREEN"]
        )
        confirmation_embed = add_logo_to_embed(confirmation_embed)
        
        # Send confirmation message
        confirmation_message = await ctx.send(embed=confirmation_embed)
        
        # Close all channels
        closed_count = 0
        for channel in halal_channels:
            try:
                # Send closing notification to the channel
                close_embed = discord.Embed(
                    title="Halal Service Closed",
                    description=f"This Halal service has been closed by an administrator ({ctx.author.mention}).",
                    color=user_theme["RED"]
                )
                close_embed = add_logo_to_embed(close_embed)
                
                try:
                    await channel.send(embed=close_embed)
                except:
                    # Channel might already be inaccessible
                    pass
                
                # Delete the channel
                await channel.delete()
                closed_count += 1
                
                # Update progress every 5 channels or when all are done
                if closed_count % 5 == 0 or closed_count == len(halal_channels):
                    progress_embed = discord.Embed(
                        title="Closing All Halal Services",
                        description=f"Progress: {closed_count}/{len(halal_channels)} Halal services closed.",
                        color=user_theme["GREEN"]
                    )
                    progress_embed = add_logo_to_embed(progress_embed)
                    await confirmation_message.edit(embed=progress_embed)
                
            except Exception as e:
                logger.error(f"Error closing channel {channel.name}: {e}")
                # Continue with other channels even if one fails
                continue
        
        # Final confirmation
        final_embed = discord.Embed(
            title="All Halal Services Closed",
            description=f"Successfully closed {closed_count} Halal service(s).",
            color=user_theme["GREEN"]
        )
        final_embed = add_logo_to_embed(final_embed)
        await confirmation_message.edit(embed=final_embed)
        
    except Exception as e:
        logger.error(f"Error in closeall command: {e}")
        await ctx.send(f"An error occurred: {e}")

# --------------------------- [ Helper Functions ] ---------------------------------------------------------------------------------------------------------

# User input handler for Halal service management
async def wait_for_user_input(channel, guild, check_function, timeout=300):
    """
    Wait for a user message that contains a user mention or ID to add them to the channel
    
    Args:
        channel: The Discord channel (Halal service) to monitor
        guild: The Discord guild (server) where the Halal service is created
        check_function: A function that verifies if the message contains valid user information
        timeout: How long to wait for a response (in seconds)
    """
    try:
        # Wait for a message that passes the check
        message = await bot.wait_for('message', check=check_function, timeout=timeout)
        
        # Extract the target user to add
        target_user = None
        
        # Check if there's a direct mention
        if message.mentions:
            target_user = message.mentions[0]
        else:
            content = message.content.strip()
            
            # Check if it's a user ID
            if content.isdigit() and 17 <= len(content) <= 19:
                try:
                    # Try to fetch the user by ID
                    target_user = await bot.fetch_user(int(content))
                except discord.NotFound:
                    await channel.send("Could not find a user with that ID.")
                    return
                    
            # Check if it's a username format (@username)
            elif content.startswith('@') and len(content) > 1:
                username = content[1:]  # Remove the @ symbol
                # Try to find the user by name in the guild members
                for member in guild.members:
                    if member.name.lower() == username.lower() or member.display_name.lower() == username.lower():
                        target_user = member
                        break
                
                if not target_user:
                    await channel.send(f"Could not find a user with the name '{username}' in this server.")
                    return
        
        # If we found a valid user
        if target_user:
            # Get the service channel's permissions
            service_permissions = discord.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                attach_files=True,
                embed_links=True,
                read_message_history=True
            )
            
            # Try to add the user to the channel
            try:
                # Check if the user is already in the guild
                member = guild.get_member(target_user.id)
                
                if member:
                    # Add permissions for the member
                    await channel.set_permissions(member, overwrite=service_permissions)
                    
                    # Get theme for confirmation message from message author
                    user_theme = get_user_theme(message.author.id)
                    
                    # Send confirmation message
                    confirmation_embed = discord.Embed(
                        description=f"{target_user.mention} has been added to the Halal service channel.",
                        color=user_theme["GREEN"]
                    )
                    # Add logo to embed
                    confirmation_embed = add_logo_to_embed(confirmation_embed)
                    confirmation_msg = await channel.send(embed=confirmation_embed)
                    
                    # We're not cleaning up panels anymore as per user request
                    # Keeping all welcome messages and panels visible in the channel
                    
                    # Get the crypto type from the channel topic or name
                    crypto_type = None
                    if channel.topic and any(crypto in channel.topic.upper() for crypto in CRYPTO_CONFIG.keys()):
                        for crypto in CRYPTO_CONFIG.keys():
                            if crypto in channel.topic.upper():
                                crypto_type = crypto
                                break
                    else:
                        # Default to LTC if we can't determine it
                        crypto_type = "LTC"
                    
                    # Create and send a new role assignment panel
                    role_assignment = RoleAssignment(crypto_type)
                    await role_assignment.send_initial_embed(channel)
                else:
                    # User is not in the guild
                    await channel.send(f"The user {target_user} is not a member of this server.")
            
            except discord.Forbidden:
                await channel.send("I don't have permission to add users to this channel.")
            except Exception as e:
                logger.error(f"Error adding user to Halal service: {e}")
                await channel.send(f"An error occurred while adding the user: {e}")
        
    except asyncio.TimeoutError:
        # If no valid message was received within the timeout
        await channel.send("No user was specified within the time limit. You can still manually tag someone to add them.")
    except Exception as e:
        logger.error(f"Error in wait_for_user_input: {e}")
        await channel.send(f"An error occurred while processing your request: {e}")

# --------------------------- [ Bot Events ] ---------------------------------------------------------------------------------------------------------

# Heartbeat task to keep connection alive
async def connection_heartbeat():
    """Maintains connection health and refreshes interaction cache"""
    try:
        while True:
            # Log heartbeat for debugging
            logger.info("Connection heartbeat check...")
            
            # Wait for 5 minutes before next check
            await asyncio.sleep(300)  # 5 minutes
    except Exception as e:
        logger.error(f"Error in heartbeat task: {e}")
        
# Session keep-alive handler
@bot.event
async def on_socket_response(payload):
    # Process socket responses to keep connections alive
    pass

@bot.event
async def on_ready():
    logger.info(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"{BLUE}Bot is ready! Logged in as {bot.user}{RESET}")
    
    # Register the error handling cog
    await bot.add_cog(ErrorHandlingCog(bot))
    
    # Start the heartbeat task
    bot.loop.create_task(connection_heartbeat())

def run_bot():
    """Start the bot with error handling"""
    if not TOKEN:
        print(f"{BLUE}Error: No Discord token provided. Please set the DISCORD_TOKEN environment variable.{RESET}")
        print(f"Looking for token in environment: {'TOKEN exists' if TOKEN else 'TOKEN missing'}")
        return
    
    # Start the keep_alive web server in a separate thread
    keep_alive()
    
    try:
        bot.run(TOKEN)
    except discord.errors.LoginFailure:
        print(f"{BLUE}Error: Invalid Discord token. Please check your token and try again.{RESET}")
    except Exception as e:
        print(f"{BLUE}Error starting bot: {e}{RESET}")

if __name__ == "__main__":
    run_bot()