#!/usr/bin/env python3
"""
Robust script to run the Discord bot with keepalive server.
This ensures the bot continues running even when the browser is closed
and automatically restarts if it crashes.
"""
import os
import sys
import time
import subprocess
import threading
import logging
from flask import Flask
from keep_alive import keep_alive

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bot_launcher")

def main():
    """Start the bot with auto-restart capability"""
    # First, start the keep-alive server
    keep_alive()
    
    logger.info("Starting Discord bot...")
    
    # Use an infinite loop to restart the bot if it crashes
    while True:
        try:
            # Import and run the bot directly
            import bot
            bot.run_bot()
        except Exception as e:
            logger.error(f"Bot crashed with error: {e}")
            logger.info("Restarting in 10 seconds...")
            time.sleep(10)

if __name__ == "__main__":
    main()