import os
import time
import threading
import subprocess
import logging
from flask import Flask, render_template_string

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bot_manager")

# Bot process global variable
bot_process = None

def is_bot_running():
    """Check if the bot process is running"""
    global bot_process
    return bot_process is not None and bot_process.poll() is None

def start_bot():
    """Start the bot process"""
    global bot_process
    if is_bot_running():
        logger.info("Bot is already running")
        return
    
    logger.info("Starting bot process...")
    bot_process = subprocess.Popen(["python", "all_in_one.py"], 
                                  stdout=subprocess.PIPE, 
                                  stderr=subprocess.STDOUT)
    logger.info("Bot process started")

def bot_monitor():
    """Monitor thread to ensure bot is always running"""
    while True:
        if not is_bot_running():
            logger.warning("Bot is not running. Restarting...")
            start_bot()
        time.sleep(60)  # Check every minute

# Create Flask app for web server
app = Flask(__name__)

@app.route('/')
def home():
    """Home page showing bot status"""
    status = "Running" if is_bot_running() else "Stopped"
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Discord Bot Monitor</title>
        <meta http-equiv="refresh" content="60">
        <style>
            body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #2c2f33; color: #fff; }}
            .container {{ max-width: 800px; margin: 0 auto; background: #23272a; padding: 20px; border-radius: 8px; }}
            h1 {{ color: #7289da; }}
            .status {{ padding: 10px; background: #2f3136; border-radius: 4px; }}
            .running {{ color: #43b581; }}
            .stopped {{ color: #f04747; }}
            .action {{ margin-top: 20px; }}
            .button {{ display: inline-block; padding: 10px 15px; background: #7289da; color: white; text-decoration: none; border-radius: 4px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Discord Bot Monitor</h1>
            <div class="status">
                <h2>Status: <span class="{'running' if status == 'Running' else 'stopped'}">{status}</span></h2>
                <p>This page automatically refreshes every 60 seconds</p>
            </div>
            <div class="action">
                <a href="/restart" class="button">Restart Bot</a>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/ping')
def ping():
    """Endpoint for UptimeRobot to ping"""
    return "Pong!"

@app.route('/restart_bot')
def restart_bot():
    """Endpoint to restart the bot"""
    global bot_process
    
    logger.info("Restart requested")
    # Kill the existing process if running
    if is_bot_running():
        logger.info("Terminating current bot process")
        bot_process.terminate()
        bot_process.wait(timeout=5)
    
    # Start a new process
    start_bot()
    
    return "Bot restarted. <a href='/'>Return to home</a>"

if __name__ == "__main__":
    # Start the monitor thread
    monitor_thread = threading.Thread(target=bot_monitor, daemon=True)
    monitor_thread.start()
    
    # Start the bot at the beginning
    start_bot()
    
    # Run the web server
    app.run(host='0.0.0.0', port=5000)