import discord
from discord.ext import commands
import logging
import asyncio
import traceback

# Configure logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('middleware_fix')

class InteractionErrorHandler:
    """
    Utility class for handling interaction errors and preventing 
    "This interaction failed" messages in Discord.
    """
    
    @staticmethod
    async def safe_respond(interaction, **kwargs):
        """
        Safely respond to an interaction, handling cases where the interaction
        may have already been responded to.
        
        Args:
            interaction: The Discord interaction object
            **kwargs: Keyword arguments to pass to the response methods
                - defer: Boolean indicating whether to defer the response
                - ephemeral: Boolean indicating whether the response should be ephemeral
                - content: The message content
                - embed: A discord.Embed object
                - view: A discord.ui.View object
                - etc.
                
        Returns:
            The response or followup message object, or None if an error occurred
        """
        try:
            # Check if 'defer' is in kwargs and remove it for later use
            defer = kwargs.pop('defer', False)
            
            # If the interaction hasn't been responded to yet
            if not interaction.response.is_done():
                if defer:
                    # Defer the response (useful for long operations)
                    await interaction.response.defer(
                        ephemeral=kwargs.get('ephemeral', False)
                    )
                    # Return the followup object for convenience
                    return interaction.followup
                else:
                    # Send an immediate response
                    await interaction.response.send_message(**kwargs)
                    return None
            else:
                # If already responded, use followup
                return await interaction.followup.send(**kwargs)
        except discord.errors.InteractionResponded:
            # If the interaction was already responded to, use followup
            try:
                return await interaction.followup.send(**kwargs)
            except Exception as e:
                logger.error(f"Error sending followup: {e}")
                return None
        except Exception as e:
            logger.error(f"Error in safe_respond: {e}\n{traceback.format_exc()}")
            # Try followup as last resort
            try:
                return await interaction.followup.send(**kwargs)
            except Exception as e2:
                logger.error(f"Followup also failed: {e2}")
                return None

    @staticmethod
    async def safe_defer(interaction, ephemeral=False):
        """
        Safely defer an interaction response, handling cases where
        the interaction may have already been responded to.
        
        Args:
            interaction: The Discord interaction object
            ephemeral: Boolean indicating whether the response should be ephemeral
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if not interaction.response.is_done():
                await interaction.response.defer(ephemeral=ephemeral)
                return True
            return False
        except Exception as e:
            logger.error(f"Error deferring interaction: {e}")
            return False

    @staticmethod
    async def safe_edit(interaction, **kwargs):
        """
        Safely edit an interaction response, handling cases where
        the interaction may need a followup instead.
        
        Args:
            interaction: The Discord interaction object
            **kwargs: Keyword arguments for the edit method
            
        Returns:
            The edited message, or None if an error occurred
        """
        try:
            if interaction.response.is_done():
                # If we've responded with defer, we need to use followup.edit_message
                # If we directly responded, we can use original_response()
                try:
                    # Try to edit the original response
                    return await interaction.original_response().edit(**kwargs)
                except (discord.NotFound, AttributeError):
                    # If original_response fails, try followup as a fallback
                    return await interaction.followup.send(**kwargs)
            else:
                # If we haven't responded yet, respond now
                await interaction.response.send_message(**kwargs)
                return await interaction.original_response()
        except Exception as e:
            logger.error(f"Error in safe_edit: {e}")
            # Try to send a new message as last resort
            try:
                return await interaction.followup.send(**kwargs)
            except:
                return None

    @staticmethod
    async def handle_long_task(interaction, task_func, ephemeral=True, success_message="Task completed!", error_message="An error occurred"):
        """
        Handle a long-running task with proper interaction response management.
        
        Args:
            interaction: The Discord interaction object
            task_func: Async function that performs the long task
            ephemeral: Whether the response should be ephemeral
            success_message: Message to send on successful completion
            error_message: Message to send if an error occurs
            
        Returns:
            The result of task_func if successful, None otherwise
        """
        try:
            # Defer immediately to prevent interaction timeout
            await InteractionErrorHandler.safe_defer(interaction, ephemeral=ephemeral)
            
            # Execute the long task
            result = await task_func()
            
            # Send completion message
            await interaction.followup.send(success_message)
            
            return result
        except Exception as e:
            logger.error(f"Error in long task: {e}\n{traceback.format_exc()}")
            await interaction.followup.send(f"{error_message}: {str(e)}")
            return None

class ErrorHandlingCog(commands.Cog):
    """
    Cog for handling global interaction errors in a Discord bot.
    """
    
    def __init__(self, bot):
        self.bot = bot
        
    @commands.Cog.listener()
    async def on_application_command_error(self, ctx, error):
        """Handle errors from application commands."""
        logger.error(f"Application command error: {error}\n{traceback.format_exc()}")
        
        try:
            if not ctx.response.is_done():
                await ctx.response.send_message(
                    f"An error occurred while processing your command: {error}",
                    ephemeral=True
                )
            else:
                await ctx.followup.send(
                    f"An error occurred while processing your command: {error}",
                    ephemeral=True
                )
        except Exception as e:
            logger.error(f"Error handling command error: {e}")
    
    @commands.Cog.listener()
    async def on_interaction(self, interaction):
        """Log all interactions for debugging."""
        if interaction.type == discord.InteractionType.component:
            logger.info(f"Component interaction received: {interaction.data}")
    
# Example usage:
"""
# Add this to your main bot file

from middleware_fix import InteractionErrorHandler, ErrorHandlingCog

# In your button callback:
@discord.ui.button(label="Do Something", style=discord.ButtonStyle.primary)
async def my_button(self, interaction, button):
    await InteractionErrorHandler.safe_respond(
        interaction,
        content="Processing your request...",
        ephemeral=True
    )
    
    # Do your long task here
    await asyncio.sleep(5)  # Example long task
    
    # Send a followup when done
    await interaction.followup.send("Task completed!")

# Register the error handling cog
async def setup(bot):
    await bot.add_cog(ErrorHandlingCog(bot))
"""

if __name__ == "__main__":
    # This file is meant to be imported, not run directly
    print("This is a utility module for Discord bots to handle interaction errors.")
    print("Import this module in your bot code to use its functionality.")
