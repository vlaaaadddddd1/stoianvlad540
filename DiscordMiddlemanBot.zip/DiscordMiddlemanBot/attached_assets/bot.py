import discord
from discord.ext import commands
from discord.ui import View, Button, Select
import asyncio
import random

# Define colors
GREEN_COLOR = discord.Color.green()
RED_COLOR = discord.Color.red()

# Define constants
ADMIN_ROLE_ID = 1359445037552898141  # Replace with your actual admin role ID

intents = discord.Intents.default()
intents.guilds = True
intents.guild_messages = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_interaction_error(interaction: discord.Interaction, error: Exception):
    try:
        # Check if the interaction has already been responded to
        if not interaction.response.is_done():
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="Error",
                    description="An error occurred while processing your request. Please try again.",
                    color=RED_COLOR
                ),
                ephemeral=True
            )
        print(f"Interaction Error: {error}")
    except Exception as e:
        print(f"Failed to handle interaction error: {e}")

async def select_callback(interaction: discord.Interaction):
    try:
        # Defer the response to avoid "Interaction Failed"
        if not interaction.response.is_done():
            await interaction.response.send_message("Processing your request...", ephemeral=True)
        await interaction.response.defer(ephemeral=True)

        # Process the interaction logic
        crypto = interaction.data['values'][0]
        user = interaction.user

        # Create or get the "cryptocurrency" category
        category_name = "cryptocurrency"
        category = discord.utils.get(interaction.guild.categories, name=category_name)
        if not category:
            category = await interaction.guild.create_category(name=category_name)

        # Set channel permissions
        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            discord.Object(ADMIN_ROLE_ID): discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }

        # Create a new ticket channel
        current_ticket_id = random.randint(100, 9999)
        channel = await interaction.guild.create_text_channel(f"ticket-{current_ticket_id}", category=category, overwrites=overwrites)

        # Send a follow-up message to the user
        await interaction.followup.send(
            embed=discord.Embed(
                title="Ticket Created",
                description=f"Ticket {channel.mention} created for {crypto}.",
                color=GREEN_COLOR
            ),
            ephemeral=True
        )

        # Send an initial message in the ticket channel
        await channel.send(
            embed=discord.Embed(
                title="Welcome to Your Ticket",
                description=f"This ticket is for a deal involving **{crypto}**. Please wait for further instructions.",
                color=GREEN_COLOR
            )
        )

        # Wait for user response
        def check(msg):
            return msg.channel == channel and msg.author == user

        try:
            message = await bot.wait_for("message", timeout=60.0, check=check)
            await interaction.followup.send(f"Received: {message.content}")
        except asyncio.TimeoutError:
            await interaction.followup.send("You took too long to respond. Please try again.", ephemeral=True)

    except Exception as e:
        print(f"Error in select_callback: {e}")

@discord.ui.button(label="Long Task", style=discord.ButtonStyle.green)
async def long_task_button(self, interaction: discord.Interaction, button: Button):
    await interaction.response.defer(ephemeral=True)  # Defer the response
    # Perform the long-running task
    await asyncio.sleep(10)  # Simulate a long task
    await interaction.followup.send("Task completed!")