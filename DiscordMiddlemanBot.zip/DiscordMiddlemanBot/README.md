# Discord Bot - 24/7 Hosting on Railway

This repository contains a Discord bot for cryptocurrency transaction management, with secure P2P trading features.

## Deploying to Railway (24/7 Hosting)

### Prerequisites
- A GitHub account
- A Railway.app account (sign up at https://railway.app)

### Setup Steps

1. **Create a GitHub Repository**
   - Create a new repository on GitHub
   - Upload all the files from this project to your repository

2. **Set Up Railway**
   - Log in to Railway.app using your GitHub account
   - Click "New Project"
   - Select "Deploy from GitHub repo"
   - Choose the repository you created in step 1
   - Click "Deploy Now"

3. **Configure Environment Variables**
   - In your Railway project, go to the "Variables" tab
   - Add the following variable:
     - `DISCORD_TOKEN`: Your Discord bot token

4. **Verify Deployment**
   - Railway will automatically build and deploy your bot
   - Check the "Deployments" tab to see deployment progress
   - Once deployed, your bot will run 24/7 automatically

## Maintenance

- Your bot will now run 24/7 on Railway's servers
- Railway will automatically restart your bot if it crashes
- You can view logs in the "Deployments" tab

## Important Files

- `railway_bot.py`: The main bot file optimized for Railway
- `Procfile`: Tells Railway how to run your bot
- `railway-requirements.txt`: Lists Python dependencies

## Upgrading

To update your bot in the future:
1. Make changes to your local files
2. Commit and push to GitHub
3. Railway will automatically detect changes and redeploy

## Troubleshooting

If your bot goes offline:
1. Check the Railway logs for errors
2. Verify your Discord token is still valid
3. Ensure you haven't exceeded Railway's free tier limits (restart if needed)