#!/usr/bin/env python3
"""
Bot runner script for Discord bot.
This script automatically runs the fixed version of the bot.
"""
import os
import sys
import time
import logging
from keep_alive import keep_alive

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bot_runner")

def main():
    # Start the keepalive server
    keep_alive()
    
    # Loop to restart the bot if it crashes
    while True:
        try:
            # Import and run the bot
            import bot
            logger.info("Starting Discord bot...")
            bot.run_bot()
        except Exception as e:
            logger.error(f"Bot crashed with error: {e}")
            logger.info("Restarting in 10 seconds...")
            time.sleep(10)

if __name__ == "__main__":
    main()