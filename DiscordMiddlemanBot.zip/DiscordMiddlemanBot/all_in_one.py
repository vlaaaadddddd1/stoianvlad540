#!/usr/bin/env python3
"""
Ultimate 24/7 Discord Bot Solution
This script combines the Discord bot and web server in a single process
with multiple threads to ensure it stays online at all times.
"""
import os
import sys
import time
import threading
import datetime
import signal
import logging
from flask import Flask, render_template_string
import discord
from discord.ext import commands, tasks
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('always_on_bot')

# Load environment variables
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    logger.error("No Discord token found in .env file!")
    sys.exit(1)

# Create Flask app
app = Flask(__name__)

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="p ", intents=intents)

# Global variables
start_time = datetime.datetime.now()
restart_flag = False

# Simple status page HTML template
STATUS_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Discord Bot Status</title>
    <meta http-equiv="refresh" content="60">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #2c2f33;
            color: #ffffff;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #23272a;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }
        h1 {
            color: #7289da;
        }
        .status-card {
            background-color: #2f3136;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 15px;
        }
        .online {
            color: #43b581;
        }
        .indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .indicator.green {
            background-color: #43b581;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 0.8em;
            color: #72767d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Discord Bot Status</h1>
        
        <div class="status-card">
            <h2><span class="indicator green"></span> Bot Status: <span class="online">Online</span></h2>
            <p>Bot Name: {{ bot_name }}</p>
            <p>Uptime: {{ uptime }}</p>
            <p>Last Ping: {{ current_time }}</p>
        </div>

        <div class="status-card">
            <h2>System Information</h2>
            <p>Web Server: Active</p>
            <p>Heartbeat: Active (5 minute intervals)</p>
        </div>
        
        <div class="footer">
            <p>This page automatically refreshes every 60 seconds.</p>
            <p>Last updated: {{ current_time }}</p>
        </div>
    </div>
</body>
</html>
"""

@app.route('/')
def home():
    """Status page for the bot"""
    uptime = datetime.datetime.now() - start_time
    days, seconds = uptime.days, uptime.seconds
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    
    uptime_str = f"{days}d {hours}h {minutes}m {seconds}s"
    
    try:
        bot_name = f"{bot.user.name}#{bot.user.discriminator}" if bot.user else "Connecting..."
    except:
        bot_name = "Connecting..."
    
    return render_template_string(STATUS_PAGE, 
                                 bot_name=bot_name,
                                 uptime=uptime_str,
                                 current_time=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

@app.route('/ping')
def ping():
    """Endpoint for UptimeRobot to ping"""
    return "Pong!"

@app.route('/restart')
def restart():
    """Endpoint to restart the bot"""
    global restart_flag
    restart_flag = True
    return "Restart signal sent. Bot will restart shortly."

def run_web_server():
    """Run the Flask web server"""
    app.run(host='0.0.0.0', port=5000)

@bot.event
async def on_ready():
    """Called when the bot is ready"""
    logger.info(f"Logged in as {bot.user}")
    print(f"\033[94mBot is ready! Logged in as {bot.user}\033[0m")
    
    # Start the heartbeat task
    if not connection_heartbeat.is_running():
        connection_heartbeat.start()
    
    # Start the before_heartbeat task if not running
    if not before_heartbeat.is_running():
        before_heartbeat.start()

@tasks.loop(minutes=5)
async def connection_heartbeat():
    """Maintains connection health and refreshes interaction cache"""
    logger.info("Connection heartbeat check...")
    try:
        # Perform basic activity to keep the connection active
        test_guild = None
        if bot.guilds:
            test_guild = bot.guilds[0]
            
        if test_guild:
            # Try to fetch basic data to keep the connection active
            await test_guild.fetch_channels()
    except Exception as e:
        logger.error(f"Error in heartbeat: {e}")

@tasks.loop(seconds=30)
async def before_heartbeat():
    """Wait until the bot is ready before starting the heartbeat"""
    if bot.is_ready():
        # Stop this loop once the bot is ready and heartbeat is started
        before_heartbeat.cancel()
        if not connection_heartbeat.is_running():
            connection_heartbeat.start()

def signal_handler(sig, frame):
    """Handle termination signals"""
    logger.info("Shutdown signal received. Cleaning up...")
    # Gracefully disconnect from Discord
    if bot:
        bot.loop.create_task(bot.close())
    # Allow some time for cleanup before exiting
    time.sleep(1)
    sys.exit(0)

def check_restart():
    """Check if a restart has been requested and handle it"""
    global restart_flag
    if restart_flag:
        logger.info("Restart requested. Restarting bot...")
        restart_flag = False
        # Perform shutdown and restart
        if bot:
            bot.loop.create_task(bot.close())
        time.sleep(2)
        os.execv(sys.executable, ['python'] + sys.argv)

def main():
    """Main entry point for the application"""
    # Set up signal handlers for graceful termination
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Print a fancy banner
    print("""\033[94m$$$$$$$\\   $$$$$$\\  $$$$$$$\\  $$\\      $$\\ $$$$$$$$\\ $$$$$$$$\\  $$$$$$\\  $$\\   $$\\ 
$$  __$$\\ $$  __$$\\ $$  __$$\\ $$$\\    $$$ |$$  _____|\__$$  __|$$  __$$\\ $$$\\  $$ |
$$ |  $$ |$$ /  $$ |$$ |  $$ |$$$$\\  $$$$ |$$ |         $$ |   $$ /  $$ |$$$$\\ $$ |
$$$$$$$\\ |$$$$$$$$ |$$ |  $$ |$$\\$$\\$$ $$ |$$$$$\\       $$ |   $$$$$$$$ |$$ $$\\$$ |
$$  __$$\\ $$  __$$ |$$ |  $$ |$$ \\$$$  $$ |$$  __|      $$ |   $$  __$$ |$$ \\$$$$ |
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |\\$  /$$ |$$ |         $$ |   $$ |  $$ |$$ |\\$$$ |
$$$$$$$  |$$ |  $$ |$$$$$$$  |$$ | \\_/ $$ |$$$$$$$$\\    $$ |   $$ |  $$ |$$ | \\$$ |
\\_______/ \\__|  \\__|\\_______/ \\__|     \\__|\\________|   \\__|   \\__|  \\__|\\__|  \\__|
\033[0m""")

    # Start the Flask server in a separate thread
    logger.info("Starting web server thread...")
    web_thread = threading.Thread(target=run_web_server)
    web_thread.daemon = True
    web_thread.start()
    
    # Import the bot functionality
    logger.info("Importing bot module...")
    import bot
    
    # Start the main bot loop with error handling and auto-restart
    while True:
        try:
            logger.info("Starting Discord bot...")
            bot.run(TOKEN)
        except discord.errors.LoginFailure:
            logger.error("Invalid Discord token. Please check your .env file.")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Bot crashed with error: {e}")
            logger.info("Attempting to restart the bot in 10 seconds...")
            time.sleep(10)
        
        # Check if we need to do a full restart
        check_restart()

if __name__ == "__main__":
    main()